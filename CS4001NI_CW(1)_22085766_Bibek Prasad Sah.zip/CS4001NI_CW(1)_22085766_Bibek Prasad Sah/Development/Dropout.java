
/**
 * Write a description of class Dropout here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dropout extends Student
{
    //initallization variable
    private int numOfRemainingModules;
    private int numOfMonthsAttended;
    private String dateOfDropout;
    private int remainingAmount;
    private boolean hasPaid;
    //constructor methods
    public Dropout(String dateOfBirth,String studentName,int courseDuration,int tuitionFee,int numOfRemainingModules,int numOfMonthsAttended,String dateOfDropout)
    {
        super(dateOfBirth,courseDuration,studentName,tuitionFee);//call to parent class constructor 
        /* call to parent class setter methods where setter methods variable name is not passed in constructor methods parameter.
         * So, we have given getter methods of the same variable as a parameter called setter methods*/       
        super.setenrollmentID(this.getenrollmentID());
        super.setcourseName(this.getcourseName());
        super.setdateOfEnrollement(this.getdateOfEnrollement());
        //initallization variable as a new variable
        this.numOfRemainingModules=numOfRemainingModules;
        this.numOfMonthsAttended=numOfMonthsAttended;
        this.dateOfDropout=dateOfDropout;
        this.remainingAmount=0;
        this.hasPaid=false;
    }
    //accessor method is also called getter method.
    public int getnumOfRemainingModules()
    {
        return this.numOfRemainingModules;
    }

    public int getnumOfMonthsAttended()
    {
        return this.numOfMonthsAttended;
    }

    public String getdateOfDropout()
    {
        return this.dateOfDropout;
    }

    public int getremainingAmount()
    {
        return this.remainingAmount;
    }

    public boolean gethasPaid()
    {
        return this.hasPaid;
    }
    //billsPayable methods
    public void billsPayable()
    {
        //using billsPayable and getter method is used in place of variable because variable has private in parent class 
        this.remainingAmount=(this.getcourseDuration() - numOfMonthsAttended) * this.gettuitionFee();
        //using condition to check remainingAmount to hasPaid set value
        if(this.remainingAmount==0)
        {
            this.hasPaid=true;
        }
    }
    //removeStudent methods
    public void removeStudent()
    {
        //if the remaining amount is 0(Zero) then the student is removed and value should be empty String
        if(this.hasPaid) 
        {
            this.setdateOfBirth("");//value is set as empty string
            this.setcourseName("");
            this.setstudentName("");
            this.setdateOfEnrollement("");
            this.setcourseDuration(0);
            this.settuitionFee(0);
            this.dateOfDropout="";
            this.setenrollmentID(0);//value is set as Zero(0)
            this.numOfRemainingModules=0;
            this.numOfMonthsAttended=0;
            this.remainingAmount=0;
        }
        else
        {
            //else condition if all bills are not cleared
            System.out.println("All bills not cleared");
        }
    }
    //display methods
    @Override
    public void display()
    {
        super.display();//made a call to parent class display method
        //printing the values of child attributes
        System.out.println("The number of remaining modules are"+ this.getnumOfRemainingModules());
        System.out.println(" The number of months attended is"+ this.getnumOfMonthsAttended());
        System.out.println("Date of Dropout"+this.getdateOfDropout());
        System.out.println("The remaining amount is"+this.getremainingAmount());
    }
}

